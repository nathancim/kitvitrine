// Config utilisée par « npm run build » : vos couleurs de tailwind.config.js, transformées en
// variables CSS pour que le mode édition (bouton « Couleurs ») puisse les changer.
const path = require('path');
module.exports = require('./kv-couleurs.cjs').withVars(require('./tailwind.config.js'), path.join(__dirname, '../*.html'));
