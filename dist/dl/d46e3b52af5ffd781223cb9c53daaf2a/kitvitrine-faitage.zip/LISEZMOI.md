# Faîtage — Site vitrine pour couvreur zingueur

Merci pour votre achat ! Ce dossier contient un site vitrine complet, prêt à être mis en ligne.

## Contenu

- `index.html` : la page du site. Ouvrez-la dans votre navigateur pour la voir.
- `assets/styles.css` : la feuille de style compilée (ne pas modifier à la main).
- `assets/fonts/` : les polices, hébergées avec le site (aucun appel à Google Fonts).
- `src/input.css` et `tailwind.config.js` : les sources pour changer couleurs et polices.

## Modifier les textes

Ouvrez `index.html` dans un éditeur de texte (VS Code, Notepad++, Sublime Text…).
Remplacez le nom, les textes, le téléphone, l'e-mail et la zone d'intervention.
Enregistrez puis rechargez la page dans le navigateur.

## Changer les couleurs ou les polices

1. Installez Node.js (https://nodejs.org).
2. Dans ce dossier, lancez : `npm install`
3. Modifiez les couleurs dans `tailwind.config.js`.
4. Recompilez : `npm run build` (ou `npm run dev` pour recompiler à chaque modification).

## Formulaire de contact

Le formulaire n'envoie rien tant qu'il n'est pas relié à un service.
Le plus simple : Netlify Forms (ajoutez `data-netlify="true"` sur la balise `<form>`) ou Formspree (remplacez `action="#"` par l'adresse fournie).

## Mettre en ligne

Glissez le dossier complet sur https://app.netlify.com/drop, ou envoyez-le par FTP chez votre hébergeur (OVH, o2switch, Ionos…).
Pensez à ajouter vos mentions légales, obligatoires en France pour un site professionnel.

## Besoin d'aide ?

Répondez simplement à l'e-mail de confirmation de commande.
