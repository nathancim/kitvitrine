# Faîtage — Site vitrine pour couvreur zingueur

Merci pour votre achat ! Ce dossier contient un site vitrine complet, prêt à être mis en ligne.

## Contenu

- `index.html` : la page du site. Ouvrez-la dans votre navigateur pour la voir.
- `assets/styles.css` : la feuille de style compilée (ne pas modifier à la main).
- `assets/fonts/` : les polices, hébergées avec le site (aucun appel à Google Fonts).
- `MODIFIER-MON-SITE.html` : ouvre le site en mode édition pour changer les textes.
- `sources-tailwind/` : les sources pour changer couleurs et polices (inutile pour la mise en ligne).

## Modifier les textes (sans rien installer)

1. Double-cliquez sur `MODIFIER-MON-SITE.html` : votre site s'ouvre dans le navigateur, en mode édition.
2. Cliquez sur n'importe quel texte et tapez par-dessus (nom, téléphone, e-mail, tarifs, avis…).
3. Cliquez sur « Télécharger ma page », puis remplacez `index.html` dans ce dossier par le fichier téléchargé.

Guide illustré : https://kitvitrine.pages.dev/guide/

Vous préférez un éditeur de texte ? Ouvrez `index.html` dans VS Code ou Notepad++, cherchez le texte à changer (Ctrl+F) et remplacez-le.

## Changer les couleurs ou les polices

1. Installez Node.js (https://nodejs.org).
2. Ouvrez un terminal dans le dossier `sources-tailwind` et lancez : `npm install`
3. Modifiez les couleurs dans `sources-tailwind/tailwind.config.js`.
4. Recompilez : `npm run build` (la feuille `assets/styles.css` est mise à jour).

## Formulaire de contact

Le formulaire n'envoie rien tant qu'il n'est pas relié à un service.
Le plus simple : Netlify Forms (ajoutez `data-netlify="true"` sur la balise `<form>`) ou Formspree (remplacez `action="#"` par l'adresse fournie).

## Mettre en ligne

Glissez le dossier complet sur https://app.netlify.com/drop (gratuit, pas besoin de compte pour commencer), ou envoyez-le par FTP chez votre hébergeur (OVH, o2switch, Ionos…). Guide illustré : https://kitvitrine.pages.dev/guide/
Pensez à ajouter vos mentions légales, obligatoires en France pour un site professionnel.

## Besoin d'aide ?

Répondez simplement à l'e-mail de confirmation de commande.
